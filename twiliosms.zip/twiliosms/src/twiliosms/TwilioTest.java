package twiliosms;
import java.util.*; 
import com.twilio.sdk.*; 
import com.twilio.sdk.resource.factory.*; 
import com.twilio.sdk.resource.instance.*; 
import com.twilio.sdk.resource.list.*; 
 
public class TwilioTest { 
 // Find your Account Sid and Token at twilio.com/user/account 
 public static final String ACCOUNT_SID = "AC4e3c68dfa43b870497b841c8f83992d2"; 
 public static final String AUTH_TOKEN = "97a41ac9350a752f082ceb100cd0696e"; 
 
 public static void main(String[]args) throws TwilioRestException { 
  TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN); 
 
   // Build the parameters 
   List<org.apache.http.NameValuePair> params = new ArrayList<org.apache.http.NameValuePair>(); 
   params.add(new org.apache.http.message.BasicNameValuePair("To", "+18046178850")); 
   params.add(new org.apache.http.message.BasicNameValuePair("From", "+18045776450 ")); 
   params.add(new org.apache.http.message.BasicNameValuePair("Body", "Hey Jenny! Good luck on the bar exam!"));  
   MessageFactory messageFactory = client.getAccount().getMessageFactory(); 
   Message message = messageFactory.create(params); 
   System.out.println(message.getSid()); 
 } 
}